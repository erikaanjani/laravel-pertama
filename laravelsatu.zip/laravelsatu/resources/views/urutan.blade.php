extends('layoutss.app')

@section('title, 'urutan')

@@section('content')

@foreach ($numbers as $number)
   <h>urutan ke - {{ $numbers['ke'] }}</h1>
    <h3>nomor ke - {{ $numbers['nomor'] }}</h3>
@endforeach

@endsection